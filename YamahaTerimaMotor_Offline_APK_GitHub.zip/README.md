# Yamaha Terima Motor - Offline APK

Project ini membungkus PWA asli ke Android WebView lokal.

- Tidak membutuhkan website/URL online untuk membuka aplikasi.
- `index.html`, `manifest.json`, `sw.js`, template, dan ikon disimpan di APK.
- Foto dari galeri dan kamera dapat digunakan.
- Tombol Simpan diarahkan untuk menyimpan hasil ke Galeri.
- Fitur nama lokasi GPS membutuhkan izin lokasi; nama wilayah melalui OpenStreetMap membutuhkan internet. Tanpa internet, fitur utama foto/form tetap berjalan.

## Build

GitHub Actions: `.github/workflows/build-apk.yml`

Buka **Actions → Build Yamaha Terima Motor - Offline APK → Run workflow**.

Hasil APK tersedia di **Artifacts**.
